<?php
/**
 * Webent — portable PHP backend.
 *
 * A drop-in replacement for the Node server and the Cloudflare Worker, for hosts
 * that run PHP and nothing else (Hostinger, cPanel, shared hosting, XAMPP, any
 * Apache/LiteSpeed box). It answers exactly the same routes with the same JSON
 * shapes, the same validation and the same wording, so the front end cannot tell
 * the difference:
 *
 *   GET  /api/health
 *   POST /api/inquiries          store an inquiry (validated server-side)
 *   POST /api/admin/login        owner sign-in (session cookie)
 *   GET  /api/admin/session      current session state
 *   GET  /api/admin/inquiries    list stored inquiries (auth required)
 *   POST /api/admin/logout       destroy the session
 *   GET  /robots.txt, /sitemap.xml  (only if those files are missing)
 *
 * Storage: JSON files in ./data (no database needed, works on shared hosting).
 * E-mail: uses PHP mail() when MAIL_TO is set — many shared hosts allow it.
 *
 * Configuration: copy api-config.sample.php to api-config.php and set the
 * password. Environment variables of the same names win if present.
 */

declare(strict_types=1);

/* ------------------------------------------------------------------ config */

$CONFIG = [];
if (is_file(__DIR__ . '/api-config.php')) {
    $loaded = require __DIR__ . '/api-config.php';
    if (is_array($loaded)) {
        $CONFIG = $loaded;
    }
}

function cfg(string $key, string $fallback = ''): string
{
    global $CONFIG;
    $env = getenv($key);
    if (is_string($env) && $env !== '') {
        return $env;
    }
    return isset($CONFIG[$key]) && $CONFIG[$key] !== '' ? (string) $CONFIG[$key] : $fallback;
}

$ADMIN_PASSWORD = cfg('admin_password');
$MAIL_TO        = cfg('mail_to');
$MAIL_FROM      = cfg('mail_from', 'no-reply@' . ($_SERVER['HTTP_HOST'] ?? 'localhost'));
$SITE_URL       = rtrim(cfg('site_url', 'https://' . ($_SERVER['HTTP_HOST'] ?? 'localhost')), '/');
$DATA_DIR       = cfg('data_dir', __DIR__ . '/data');

$COOKIE      = 'webent_admin';
$SESSION_TTL = 8 * 60 * 60;      // 8 hours, same as the Node server
$MIN_FILL_MS = 1200;             // bots submit instantly
$RATE_WINDOW = 15 * 60;          // seconds
$RATE_MAX    = 6;                // accepted submissions per IP per window
$DUP_WINDOW  = 120;              // seconds — same email + service

/** Mirrors shared/business.json — the single source of truth for prices. */
$SERVICES = [
    'landing-page' => [
        'name' => 'Landing Page', 'price' => 3000, 'wasPrice' => 15000, 'registrationFee' => 500,
    ],
    'one-page-website' => [
        'name' => 'One-Page Website', 'price' => 4000, 'wasPrice' => 20000, 'registrationFee' => 1000,
    ],
    'multi-page-website' => [
        'name' => 'Multi-Page Website', 'price' => 10000, 'wasPrice' => 50000, 'registrationFee' => 3000,
    ],
];
$CURRENCY = 'PKR';
$OFFER_LIVE = true;              // rolling 80% offer never expires for a visitor

/* ------------------------------------------------------------------ helpers */

function send_json(array $body, int $status = 200, array $headers = []): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
    foreach ($headers as $name => $value) {
        header($name . ': ' . $value);
    }
    echo json_encode($body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function ensure_dir(string $dir): void
{
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    // keep the JSON store out of the web root if the host allows it
    $guard = rtrim($dir, '/') . '/.htaccess';
    if (!is_file($guard)) {
        @file_put_contents(
            $guard,
            "<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n"
            . "<IfModule !mod_authz_core.c>\n  Order allow,deny\n  Deny from all\n</IfModule>\n"
        );
    }
}

function read_store(string $file, array $fallback = []): array
{
    if (!is_file($file)) {
        return $fallback;
    }
    $handle = @fopen($file, 'rb');
    if (!$handle) {
        return $fallback;
    }
    flock($handle, LOCK_SH);
    $raw = stream_get_contents($handle);
    flock($handle, LOCK_UN);
    fclose($handle);
    $data = json_decode((string) $raw, true);
    return is_array($data) ? $data : $fallback;
}

function write_store(string $file, array $data): bool
{
    $handle = @fopen($file, 'cb+');
    if (!$handle) {
        return false;
    }
    flock($handle, LOCK_EX);
    ftruncate($handle, 0);
    rewind($handle);
    $ok = fwrite($handle, json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)) !== false;
    fflush($handle);
    flock($handle, LOCK_UN);
    fclose($handle);
    return $ok;
}

/**
 * Some shared hosts ship PHP without mbstring; fall back to byte counts rather
 * than fataling. Only affects non-ASCII text lengths by a few characters.
 */
function text_len(string $value): int
{
    return function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
}

function text_lower(string $value): string
{
    return function_exists('mb_strtolower') ? mb_strtolower($value) : strtolower($value);
}

function client_ip(): string
{
    foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $key) {
        if (!empty($_SERVER[$key])) {
            $value = explode(',', (string) $_SERVER[$key])[0];
            return trim($value);
        }
    }
    return 'unknown';
}

function body_json(): array
{
    $raw = file_get_contents('php://input');
    if (!is_string($raw) || $raw === '') {
        return is_array($_POST) ? $_POST : [];
    }
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function make_reference(): string
{
    return 'WB-' . strtoupper(substr(bin2hex(random_bytes(5)), 0, 9));
}

function request_path(): string
{
    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    $path = parse_url($uri, PHP_URL_PATH);
    $path = is_string($path) ? $path : '/';
    // strip a subdirectory install (/webent/api/... → /api/...)
    $script = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
    if ($script !== '/' && $script !== '.' && strpos($path, $script) === 0) {
        $path = substr($path, strlen($script));
    }
    return '/' . ltrim($path, '/');
}

function validate_inquiry(array $body): array
{
    global $SERVICES;
    $errors = [];
    $name         = trim((string) ($body['name'] ?? ''));
    $email        = trim((string) ($body['email'] ?? ''));
    $phone        = trim((string) ($body['phone'] ?? ''));
    $serviceId    = trim((string) ($body['serviceId'] ?? ''));
    $requirements = trim((string) ($body['requirements'] ?? ''));

    if (text_len($name) < 2 || text_len($name) > 80) {
        $errors['name'] = 'Please enter your full name.';
    }
    if (!preg_match('/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i', $email) || strlen($email) > 200) {
        $errors['email'] = 'Please enter a valid email address.';
    }
    if (!preg_match('/^\+?[\d][\d\s().-]{5,24}$/', $phone) || strlen(preg_replace('/\D/', '', $phone)) < 7) {
        $errors['phone'] = 'Please enter a valid phone or WhatsApp number.';
    }
    if (!isset($SERVICES[$serviceId])) {
        $errors['serviceId'] = 'Please choose one of the three services.';
    }
    if (text_len($requirements) < 20) {
        $errors['requirements'] = 'Please describe your requirements in at least 20 characters.';
    }
    if (text_len($requirements) > 4000) {
        $errors['requirements'] = 'Please keep your requirements under 4,000 characters.';
    }

    return [
        'errors' => $errors,
        'value'  => compact('name', 'email', 'phone', 'serviceId', 'requirements'),
    ];
}

function send_notification(array $row, string $mailTo, string $mailFrom): string
{
    global $SERVICES;
    if ($mailTo === '' || !function_exists('mail')) {
        return 'not_configured';
    }
    $subject = 'New website inquiry ' . $row['reference'] . ' — ' . $row['service_name'];
    $lines = [
        'A new inquiry arrived from the website.',
        '',
        'Reference: ' . $row['reference'],
        'Name:      ' . $row['name'],
        'Email:     ' . $row['email'],
        'Phone:     ' . $row['phone'],
        'Service:   ' . $row['service_name'] . ' (' . $row['currency'] . ' ' . number_format((float) $row['service_price']) . ')',
        'Received:  ' . $row['submitted_at'],
        '',
        'Requirements:',
        $row['requirements'],
        '',
        'Read all inquiries at /admin',
    ];
    $headers = 'From: Webent <' . $mailFrom . ">\r\n" . 'Reply-To: ' . $row['email'] . "\r\n" . 'Content-Type: text/plain; charset=UTF-8';
    $sent = @mail($mailTo, $subject, implode("\r\n", $lines), $headers);
    return $sent ? 'sent' : 'failed';
}

/* ------------------------------------------------------------ route: health */

$path = request_path();
$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

ensure_dir($DATA_DIR);
$inquiriesFile = $DATA_DIR . '/inquiries.json';
$sessionsFile  = $DATA_DIR . '/sessions.json';
$rateFile      = $DATA_DIR . '/rate.json';

$inquiries = read_store($inquiriesFile);

if ($path === '/api/health' && $method === 'GET') {
    send_json([
        'ok'                => true,
        'storage'           => 'php-json',
        'inquiriesStored'   => count($inquiries),
        'emailNotifications' => $MAIL_TO !== '' ? 'configured' : 'not_configured',
        'adminPanel'        => $ADMIN_PASSWORD !== '' ? 'configured' : 'not_configured',
    ]);
}

/* -------------------------------------------------------- route: new inquiry */

if ($path === '/api/inquiries' && $method === 'POST') {
    $body = body_json();

    // 1. honeypot — real visitors never fill a hidden field
    if (trim((string) ($body['company'] ?? '')) !== '') {
        send_json(['ok' => true, 'reference' => null, 'note' => 'ignored'], 202);
    }

    // 1b. If nobody can ever read the enquiry, say so instead of storing it in a hole.
    if ($ADMIN_PASSWORD === '' && $MAIL_TO === '') {
        send_json([
            'ok'      => false,
            'message' => 'The form is not connected on this server yet. Please message us on WhatsApp or e-mail webentstudio@gmail.com.',
        ], 503);
    }

    // 2. minimum fill time
    $elapsed = $body['elapsedMs'] ?? null;
    if (!is_numeric($elapsed) || (float) $elapsed < $MIN_FILL_MS) {
        send_json([
            'ok'      => false,
            'message' => 'That was submitted a little too quickly. Please press send once more.',
        ], 400);
    }

    // 3. server-side validation
    ['errors' => $errors, 'value' => $value] = validate_inquiry($body);
    if ($errors !== []) {
        send_json([
            'ok'      => false,
            'message' => 'Please check the highlighted fields.',
            'errors'  => (object) $errors,
        ], 422);
    }

    // 4. sliding-window rate limit, counted only after validation
    $ipHash = substr(hash('sha256', client_ip()), 0, 32);
    $now = time();
    $rate = read_store($rateFile);
    $rate = array_values(array_filter($rate, static fn ($entry) => ($entry['at'] ?? 0) > $now - $RATE_WINDOW));
    $hits = 0;
    foreach ($rate as $entry) {
        if (($entry['key'] ?? '') === 'inquiry:' . $ipHash) {
            $hits++;
        }
    }
    if ($hits >= $RATE_MAX) {
        send_json([
            'ok'      => false,
            'message' => 'Too many submissions from this connection in a short time. Please try again later, or message us on WhatsApp.',
        ], 429);
    }

    // 5. duplicate guard — same email + service inside two minutes
    $email = text_lower($value['email']);
    foreach ($inquiries as $row) {
        if (
            text_lower((string) ($row['email'] ?? '')) === $email
            && ($row['service_id'] ?? '') === $value['serviceId']
            && strtotime((string) ($row['submitted_at'] ?? '')) > $now - $DUP_WINDOW
        ) {
            send_json([
                'ok'        => false,
                'message'   => 'This inquiry was already received (reference ' . $row['reference'] . '). We\'ll be in touch.',
                'reference' => $row['reference'],
            ], 409);
        }
    }

    $service = $SERVICES[$value['serviceId']];
    $row = [
        'id'            => bin2hex(random_bytes(8)),
        'reference'     => make_reference(),
        'name'          => $value['name'],
        'email'         => $email,
        'phone'         => $value['phone'],
        'service_id'    => $value['serviceId'],
        'service_name'  => $service['name'],
        'service_price' => $OFFER_LIVE ? $service['price'] : $service['wasPrice'],
        'registration_fee' => $service['registrationFee'],
        'currency'      => $CURRENCY,
        'requirements'  => $value['requirements'],
        'ip_hash'       => $ipHash,
        'user_agent'    => substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 300),
        'submitted_at'  => gmdate('Y-m-d\TH:i:s.000\Z'),
        'email_status'  => 'pending',
    ];

    $row['email_status'] = send_notification($row, $MAIL_TO, $MAIL_FROM);

    $inquiries[] = $row;
    if (!write_store($inquiriesFile, $inquiries)) {
        send_json([
            'ok'      => false,
            'message' => 'The inquiry could not be stored. Please message us on WhatsApp instead.',
        ], 500);
    }

    $rate[] = ['key' => 'inquiry:' . $ipHash, 'at' => $now];
    write_store($rateFile, $rate);

    send_json([
        'ok'                => true,
        'reference'         => $row['reference'],
        'receivedAt'        => $row['submitted_at'],
        'emailNotification' => $row['email_status'],
        'message'           => 'Inquiry received and stored.',
    ], 201);
}

/* --------------------------------------------------------------- admin: auth */

function current_session(string $sessionsFile, string $cookie): ?array
{
    $token = $_COOKIE[$cookie] ?? '';
    if (!is_string($token) || $token === '') {
        return null;
    }
    $hash = hash('sha256', $token);
    $sessions = read_store($sessionsFile);
    $expires = $sessions[$hash] ?? null;
    if (!is_int($expires) || $expires < time()) {
        return null;
    }
    return ['hash' => $hash, 'expires' => $expires];
}

if ($path === '/api/admin/session' && $method === 'GET') {
    send_json([
        'configured' => $ADMIN_PASSWORD !== '',
        'signedIn'   => current_session($sessionsFile, $COOKIE) !== null,
    ]);
}

if ($path === '/api/admin/login' && $method === 'POST') {
    if ($ADMIN_PASSWORD === '') {
        send_json(['ok' => false, 'message' => 'The admin panel is not configured on this server.'], 503);
    }
    $body = body_json();
    $password = (string) ($body['password'] ?? '');
    if ($password === '' || !hash_equals($ADMIN_PASSWORD, $password)) {
        usleep(400000); // same slow-down as the Node build
        send_json(['ok' => false, 'message' => 'That password does not match.'], 401);
    }
    $token = bin2hex(random_bytes(32));
    $sessions = read_store($sessionsFile);
    $now = time();
    foreach ($sessions as $hash => $expires) {
        if (!is_int($expires) || $expires < $now) {
            unset($sessions[$hash]);
        }
    }
    $sessions[hash('sha256', $token)] = $now + $SESSION_TTL;
    write_store($sessionsFile, $sessions);

    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    setcookie($COOKIE, $token, [
        'expires'  => $now + $SESSION_TTL,
        'path'     => '/',
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    send_json(['ok' => true, 'signedIn' => true]);
}

if ($path === '/api/admin/logout' && $method === 'POST') {
    $session = current_session($sessionsFile, $COOKIE);
    if ($session !== null) {
        $sessions = read_store($sessionsFile);
        unset($sessions[$session['hash']]);
        write_store($sessionsFile, $sessions);
    }
    setcookie($COOKIE, '', ['expires' => time() - 3600, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);
    send_json(['ok' => true, 'signedIn' => false]);
}

if ($path === '/api/admin/inquiries' && $method === 'GET') {
    if (current_session($sessionsFile, $COOKIE) === null) {
        send_json(['ok' => false, 'message' => 'Please sign in.'], 401);
    }
    $rows = array_reverse($inquiries);
    send_json(['ok' => true, 'inquiries' => array_map(static function (array $row): array {
        return [
            'reference'     => $row['reference'],
            'name'          => $row['name'],
            'email'         => $row['email'],
            'phone'         => $row['phone'],
            'service_name'  => $row['service_name'],
            'service_price' => $row['service_price'],
            'currency'      => $row['currency'],
            'requirements'  => $row['requirements'],
            'submitted_at'  => $row['submitted_at'],
            'email_status'  => $row['email_status'] ?? 'not_configured',
        ];
    }, $rows)]);
}

/* -------------------------------------------------- SEO files, if not uploaded */

if ($path === '/robots.txt' && $method === 'GET') {
    header('Content-Type: text/plain; charset=utf-8');
    echo "User-agent: *\nAllow: /\nDisallow: /admin\n\nSitemap: " . $SITE_URL . "/sitemap.xml\n";
    exit;
}

if ($path === '/sitemap.xml' && $method === 'GET') {
    $today = gmdate('Y-m-d');
    $pages = ['', '/services', '/pricing', '/contact'];
    $urls = '';
    foreach ($pages as $page) {
        $urls .= '  <url><loc>' . $SITE_URL . ($page === '' ? '/' : $page) . '</loc><lastmod>' . $today
            . '</lastmod><changefreq>monthly</changefreq><priority>' . ($page === '' ? '1.0' : '0.8') . "</priority></url>\n";
    }
    header('Content-Type: application/xml; charset=utf-8');
    echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n"
        . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n" . $urls . "</urlset>\n";
    exit;
}

/* --------------------------------------------------------- single-page routes */

if (strpos($path, '/api/') === 0) {
    send_json(['ok' => false, 'message' => 'Unknown endpoint.'], 404);
}

// Any non-file path is a page in the single-page site.
$index = __DIR__ . '/index.html';
if ($method === 'GET' && !is_file(__DIR__ . $path) && is_file($index)) {
    header('Content-Type: text/html; charset=utf-8');
    readfile($index);
    exit;
}

http_response_code(404);
echo 'Not found';
