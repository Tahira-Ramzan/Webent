<?php
/**
 * Copy this file to `api-config.php` (same folder) and fill it in.
 * Without it, the site still runs — only the form and /admin are switched off.
 *
 * If your host allows environment variables, those win over this file
 * (ADMIN_PASSWORD, MAIL_TO, MAIL_FROM, SITE_URL, DATA_DIR).
 */
return [
    // The password for /admin. Make it long; anyone with it can read enquiries.
    'admin_password' => 'CHANGE-ME-TO-A-LONG-PASSWORD',

    // Where new inquiries are e-mailed. Leave '' to turn e-mail off (PHP mail()).
    'mail_to'   => 'webentstudio@gmail.com',
    'mail_from' => 'no-reply@your-domain.com',

    // Your live address, used in the sitemap and the e-mail. No trailing slash.
    'site_url'  => 'https://your-domain.com',

    // Where the JSON store lives. Default is ./data beside this file.
    'data_dir'  => __DIR__ . '/data',
];
