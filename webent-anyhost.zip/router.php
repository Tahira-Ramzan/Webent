<?php
/**
 * Router for PHP's built-in server — handy for testing on any computer:
 *
 *     php -S localhost:8000 router.php
 *
 * Mirrors what .htaccess does on Apache: /api/* goes to api.php, real files are
 * served directly, everything else is the single-page site.
 */
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';

if (strpos($path, '/api/') === 0) {
    require __DIR__ . '/api.php';
    return true;
}

// never expose the JSON store or the config through the built-in server
if (strpos($path, '/data/') === 0 || $path === '/api-config.php' || $path === '/api-config.sample.php') {
    http_response_code(404);
    echo 'Not found';
    return true;
}

$file = __DIR__ . $path;
if ($path !== '/' && is_file($file)) {
    return false; // let the built-in server stream it
}

require __DIR__ . '/api.php';
return true;
