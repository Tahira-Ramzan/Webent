# Webent — one folder, works on any host

This folder is the whole website plus three different ways to run its contact form. You upload
the **same files** everywhere; what changes is only which parts the host can execute.

| Host type | Upload | Contact form | `/admin` |
|---|---|---|---|
| **PHP shared hosting** — Hostinger, cPanel, Namecheap, HostGator, GoDaddy, LiteSpeed/Apache | everything in this folder → `public_html` | **works** (PHP writes to `data/inquiries.json`) | **works** |
| **VPS with nginx + PHP-FPM** | same files | **works** | **works** |
| **Node host** — Render, Koyeb, Railway, Docker, any VPS | project root, `npm ci && npm run build && npm start` | **works** (SQLite) | **works** |
| **Cloudflare Workers** | `wrangler.toml` + `cloudflare/` via `wrangler deploy` | **works** (D1) | **works** |
| **Static only** — Netlify, Vercel, GitHub Pages, Firebase, S3, Cloudflare Pages | only the static files (`index.html`, `assets/`, `brand/`, `fonts/`) | says it could not send, offers WhatsApp — never fakes success | no |
| **Your own computer** | `php -S localhost:8000 router.php` | **works** | **works** |

Three backends, one front end. The page always calls `/api/health`, `/api/inquiries` and
`/api/admin/*`, and whichever backend is present answers with the same JSON — same validation,
same wording, same rules (minimum fill time, honeypot, duplicate guard, rate limit).

---

## 1. Shared hosting (Hostinger, cPanel, any PHP host) — no terminal needed

1. Upload **everything in this folder** to `public_html` (File Manager → Upload, or ZIP → Extract).
   Keep the folder structure: `index.html`, `assets/`, `brand/`, `fonts/`, `api.php`, `.htaccess`.
   Files starting with a dot can be hidden — turn on "show hidden files" so `.htaccess` goes too.
2. Rename `api-config.sample.php` to **`api-config.php`** and edit it:
   - `admin_password` → your own long password (this is the `/admin` login)
   - `mail_to` → `webentstudio@gmail.com` (or leave `''` to turn e-mail off)
   - `site_url` → `https://your-domain.com` (no trailing slash)
3. Visit `https://your-domain.com/api/health`. You want:

   ```json
   {"ok":true,"storage":"php-json","emailNotifications":"configured","adminPanel":"configured"}
   ```

4. Send yourself a test enquiry at `/contact`, then open `/admin` and sign in.

Make sure `data/` is writable (permission `755` on the folder, `644` on files). If the form says
it could not store the enquiry, that is the one thing to fix in File Manager → Permissions.

## 2. Node host

From the project root: `npm ci && npm run build && npm start`. `PORT`, `DATA_DIR`,
`ADMIN_PASSWORD`, `SITE_URL` and the `SMTP_*` variables are read from the environment. Full
walkthrough: `DEPLOY-FREE.md`.

## 3. Cloudflare Workers

`npx wrangler deploy` from the project root (config in `wrangler.toml`), storage in D1. Full
walkthrough: `cloudflare/DEPLOY-FROM-GITHUB.md`.

## 4. Static-only host

Upload only `index.html`, `assets/`, `brand/`, `fonts/`. All four pages work; the form tells the
visitor plainly that it could not send and offers WhatsApp and e-mail instead. Add the two files
from `extras/` (`robots.txt`, `sitemap.xml`) if you want search engines pointed at your domain —
edit the placeholder address inside them first.

---

## What is in this folder

| Path | What it does |
|---|---|
| `index.html`, `assets/`, `brand/`, `fonts/` | the built site — the same files every host serves |
| `api.php` | the backend for any PHP host: enquiries, admin login, robots, sitemap |
| `api-config.sample.php` | copy to `api-config.php`, then set the password and e-mail |
| `.htaccess` | Apache/LiteSpeed routing (`/api/*` → `api.php`, `/pricing` → the site), caching, headers, protection |
| `nginx.conf.example` | the same for nginx + PHP-FPM |
| `router.php` | run it locally: `php -S localhost:8000 router.php` |
| `data/` | where enquiries are stored, blocked from the web by `data/.htaccess` |
| `netlify.toml`, `vercel.json` | routing and cache headers for those two hosts |
| `extras/` | `robots.txt` and `sitemap.xml` for static-only hosts |

## Security, briefly

- `api-config.php` and everything in `data/` are blocked by `.htaccess` (403) and by nginx rules.
  Verified: `GET /data/inquiries.json` → 403, `GET /api-config.php` → 403.
- The admin session is an HttpOnly, SameSite=Lax cookie holding a random 32-byte token; only its
  SHA-256 hash is stored, and it expires after 8 hours.
- Password comparison is constant-time (`hash_equals`).
- Submissions are rate limited to 6 per IP per 15 minutes, duplicates (same e-mail + service inside
  2 minutes) are refused with the original reference, and bots that fill the hidden field get a
  silent 202 instead of a stored row.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Site loads but `/pricing` gives 404 | `.htaccess` missing or `AllowOverride` disabled | re-upload `.htaccess` (enable hidden files); on a host that forbids it, ask support to enable `mod_rewrite` |
| `/api/health` returns HTML instead of JSON | rewrite not applied, so `api.php` never runs | same as above; confirm `mod_rewrite` is on |
| `500 Internal Server Error` on every page | an `.htaccess` directive the host does not allow | comment out the `<IfModule mod_deflate>` / `<IfModule mod_expires>` blocks and retry |
| `{"ok":true,"storage":"php-json"}` but the form says it could not store | `data/` not writable | set the folder to 755 (or 775) in File Manager |
| `emailNotification: "failed"` | the host has `mail()` switched off | turn `mail_to` off and rely on `/admin`, or use a Node host with SMTP |
| `adminPanel: "not_configured"` | `api-config.php` missing or `admin_password` empty | re-do §1 step 2 |
| Form says **"The form is not connected on this server yet"** (503) | no `api-config.php` at all, so nothing could ever read the enquiry — the API refuses instead of storing it in a hole | create `api-config.php` from the sample |

## What was actually tested here

Run on this exact folder, on PHP 8.4 behind real Apache 2.4 with `.htaccess`:

- `/`, `/services`, `/pricing`, `/contact`, `/admin`, `/robots.txt`, `/sitemap.xml`, `/api/health` → 200
- Submitting the real form in a headless Chrome: “Inquiry received and stored. Reference
  WB-62FE907CF”, zero console errors
- Too-fast submit → 400 · invalid fields → 422 with per-field messages · honeypot → 202 ignored
- Duplicate → 409 echoing the first reference · 7th submit in 15 minutes → 429
- `/api/admin/inquiries` without a session → 401 · wrong password → 401 · correct password → 200,
  stored row listed · logout → 401 again
- `GET /data/inquiries.json` → 403 · `GET /api-config.php` → 403
- Asset caching (`immutable`) and HTML revalidation headers present

Also run on PHP's built-in server via `router.php`, with the same results.
